
function startApp() {
    alert("BoatBoy WebApp Started!");
}
